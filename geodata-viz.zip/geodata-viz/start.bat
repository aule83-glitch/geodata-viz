@echo off
chcp 65001 >nul
title GeoData Viz — Uruchamianie

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║         GeoData Viz — START              ║
echo  ║  GRIB2 · NetCDF · HDF5 na mapach OSM    ║
echo  ╚══════════════════════════════════════════╝
echo.

:: Sprawdź czy Docker jest zainstalowany
where docker >nul 2>&1
if %errorlevel% neq 0 (
    echo  [BŁĄD] Docker nie jest zainstalowany lub nie jest w PATH.
    echo.
    echo  Zainstaluj Docker Desktop ze strony:
    echo  https://www.docker.com/products/docker-desktop/
    echo.
    pause
    exit /b 1
)

:: Sprawdź czy Docker Desktop jest uruchomiony
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo  [BŁĄD] Docker Desktop nie jest uruchomiony.
    echo  Uruchom Docker Desktop i spróbuj ponownie.
    echo.
    pause
    exit /b 1
)

echo  [OK] Docker gotowy.
echo.
echo  Budowanie i uruchamianie kontenerów...
echo  (pierwsze uruchomienie może trwać 3-5 minut)
echo.

docker compose up --build -d

if %errorlevel% neq 0 (
    echo.
    echo  [BŁĄD] Nie udało się uruchomić kontenerów.
    echo  Sprawdź logi: docker compose logs
    pause
    exit /b 1
)

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║  Aplikacja uruchomiona!                  ║
echo  ║                                          ║
echo  ║  Frontend:  http://localhost:3000        ║
echo  ║  API docs:  http://localhost:8000/docs   ║
echo  ║                                          ║
echo  ║  Pliki danych → backend\data\            ║
echo  ╚══════════════════════════════════════════╝
echo.

:: Otwórz przeglądarkę po chwili
timeout /t 3 /nobreak >nul
start http://localhost:3000

echo  Naciśnij dowolny klawisz aby zatrzymać aplikację...
pause >nul

echo.
echo  Zatrzymywanie kontenerów...
docker compose down
echo  Gotowe. Do widzenia!
pause
